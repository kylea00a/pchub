PCHUB Host Agent — one-click setup
========================================

1. Extract this zip to C:\PCHUB-Host (Extract All — not Run)

2. Download config.json from pchub.cloud/host (same pairing code page)
   and save it in C:\PCHUB-Host

3. Double-click RUN-PCHUB.cmd — click YES on the admin prompt

4. "PCHUB Host Status" appears on your taskbar (Online / Offline)

Remote desktop uses PCHUB relay — no router setup needed.
